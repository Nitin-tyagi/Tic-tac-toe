import React from 'react'
import "../App.css";
export const Rest = ({resetBoard}) => {
  return (
    <button className='reset' onClick={resetBoard}>Reset</button>
  )
}
